from django.contrib import admin
from .models import Detalhedisciplina

admin.site.register (Detalhedisciplina)