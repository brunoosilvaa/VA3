from django.contrib import admin
from .models import Detalhecurso

admin.site.register(Detalhecurso)